Nothing fancy, just a simple Todo list app for android written in Kotlin.

Based off a Java based tutorial by @aziflaj here: https://www.sitepoint.com/starting-android-development-creating-todo-app/
